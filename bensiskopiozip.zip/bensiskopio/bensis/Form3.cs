﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace bensis

{
    public partial class Tankit : Form
    {

        public static string polttoaine = "95";
        public static string polttoaine2 = "98";
        public static string polttoaine3 = "D";
        public static int maara;
        public static int tilaus;
        public static int taysitankki = 50000;
        string fileName = AppDomain.CurrentDomain.BaseDirectory + @"\bensatankki95.txt";
        string fileNamen = AppDomain.CurrentDomain.BaseDirectory + @"\bensatankki98.txt";
        string fileNamenn = AppDomain.CurrentDomain.BaseDirectory + @"\bensatankkiD.txt";
        string fileNamennn = AppDomain.CurrentDomain.BaseDirectory + @"\tilausloki.txt";

       
        public Tankit()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
        
            using (StreamReader sr = new StreamReader(fileName))
            {
                int tilausraja = 1000;
                int maara = int.Parse(sr.ReadLine());
                textBox1.Text = "" + (maara);
                if (maara == taysitankki)
                {
                    DialogResult result = MessageBox.Show("Säiliö 95 on täynnä", "Säiliö on täynnä", MessageBoxButtons.OK);

                }
                if (maara < tilausraja)
                {
                    DialogResult result = MessageBox.Show("säiliö 95 on tyhjentymässä", "tilaa lisää polttoainetta", MessageBoxButtons.OK);

                }
            }

        }

        private void Button2_Click(object sender, EventArgs e)
        {
           
            using (StreamReader sr = new StreamReader(fileNamen))
            {

                maara = int.Parse(sr.ReadLine());
                textBox1.Text = "" + (maara);
                int tilausraja = 1000;
                if (maara == taysitankki)
                {
                    DialogResult result = MessageBox.Show("Säiliö 98 on täynnä", "Säiliö on täynnä", MessageBoxButtons.OK);

                }
                if (maara < tilausraja)
                {
                    DialogResult result = MessageBox.Show("säiliö 98 on tyhjentymässä", "tilaa lisää polttoainetta", MessageBoxButtons.OK);

                }
            }

        }

        private void Button3_Click(object sender, EventArgs e)
        {


            using (StreamReader sr = new StreamReader(fileNamenn))
            {

                maara = int.Parse(sr.ReadLine());
                textBox1.Text = "" + (maara);
                int tilausraja = 1000;
                if (maara==taysitankki)
                {
                    DialogResult result = MessageBox.Show("Säiliö D on täynnä", "Säiliö on täynnä", MessageBoxButtons.OK);

                }

                if (maara < tilausraja)
                {
                    DialogResult result = MessageBox.Show("säiliö D on tyhjentymässä", "tilaa lisää polttoainetta", MessageBoxButtons.OK);

                }

            }

        }
        public static void KirjoitaTiedostoon(int tilaus, string polttoaine, string fileNamennn)

        {
            using (StreamWriter sw = new StreamWriter(fileNamennn, true))
            {
                sw.WriteLine(DateTime.Now + " Tilataan " + tilaus + " litraa " + polttoaine);
                sw.Close();
            }

        }

        private void Button4_Click(object sender, EventArgs e)
        {


            
               


                using (StreamReader sr = new StreamReader(fileName))
                {

                    taysitankki = 50000;
                    maara = int.Parse(sr.ReadLine());
                    tilaus = (taysitankki - maara);



                   
                    sr.Close();
                if (checkBox1.Checked)
                {








                    KirjoitaTiedostoon(tilaus, polttoaine, fileNamennn);


                    Bensasailio95(tilaus, maara, fileName);
                    DialogResult result = MessageBox.Show("Tilauksesi on tallennettu", "Tilauksesi on tallennettu", MessageBoxButtons.OK);
                    
                }
                }

                

                using (StreamReader sr = new StreamReader(fileNamen))
                {
                    taysitankki = 50000;
                    maara = int.Parse(sr.ReadLine());
                    tilaus = (taysitankki - maara);
                    sr.Close();
                if (checkBox2.Checked)
                {

                    KirjoitaTiedostoon(tilaus, polttoaine2, fileNamennn);
                    Bensasailio98(tilaus, maara, fileNamen);
                    DialogResult result = MessageBox.Show("Tilauksesi on tallennettu", "Tilauksesi on tallennettu", MessageBoxButtons.OK);

                }

                }


                using (StreamReader sr = new StreamReader(fileNamenn))
                {
                    taysitankki = 50000;
                    maara = int.Parse(sr.ReadLine());
                    tilaus = (taysitankki - maara);
                    sr.Close();
                    if (checkBox3.Checked)
                    {
                        
                      
                        KirjoitaTiedostoon(tilaus, polttoaine3, fileNamennn);
                        BensasailioD(tilaus, maara, fileNamenn);
                    DialogResult result = MessageBox.Show("Tilauksesi on tallennettu", "Tilauksesi on tallennettu", MessageBoxButtons.OK);

                    }
                
               



                }
            



            void Bensasailio95(int maara, int tilaus, string fileName)
            {


                using (StreamWriter sw = new StreamWriter(fileName))
                {
                    
                    
                        sw.WriteLine(maara + tilaus);
                        sw.Close();
                    


                }

            }
            void Bensasailio98(int maara, int tilaus, string fileNamen)
            {


                using (StreamWriter sw = new StreamWriter(fileNamen))
                {

                    sw.WriteLine(maara + tilaus);
                    sw.Close();


                }

            }


            void BensasailioD(int maara, int tilaus, string fileNamenn)
            {


                using (StreamWriter sw = new StreamWriter(fileNamenn))
                {

                    sw.WriteLine(maara + tilaus);
                    sw.Close();


                }

            }



        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Button5_Click(object sender, EventArgs e)
        {
            DialogResult results = MessageBox.Show("suljetaanko ohjelma?", "Haluatko  sulkea ohjelman", MessageBoxButtons.YesNo);
            if (results == DialogResult.Yes)
            {
                Application.Exit();
            }
            
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            {
                if (checkBox1.Checked == true)
                { checkBox2.Checked = false; checkBox3.Checked = false; }
            }

        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            {
                if (checkBox2.Checked == true)
                { checkBox1.Checked = false; checkBox3.Checked = false; }
            }
        }

        private void CheckBox3_CheckedChanged(object sender, EventArgs e)
        {
            {
                if (checkBox3.Checked == true)
                { checkBox2.Checked = false; checkBox1.Checked = false; }
            }
        }
    }
}

