﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace bensis
{
    public partial class Kirjautuminen : Form
    {
        public static string kayttajatunnus;
        public static string salasana;
        public static string md5tiiviste;
        public static string kayttajamd5tiiviste;
        string fileName = AppDomain.CurrentDomain.BaseDirectory + @"\tunnukset.txt";
        string fileNamen = AppDomain.CurrentDomain.BaseDirectory + @"\md5tiiviste.txt";
        string fileNamenn = AppDomain.CurrentDomain.BaseDirectory + @"\kayttajantiiviste.txt";

        public Kirjautuminen()
        {
            InitializeComponent();
            LueTunnukset();
            Md5tiiviste();
        }

        private void LueTunnukset()
        {
            using (StreamReader sr = new StreamReader(fileName))
            {
                kayttajatunnus = sr.ReadLine();
                salasana = sr.ReadLine();
            }
        }

        private void Md5tiiviste()
        {
            using (StreamWriter sw = new StreamWriter(fileNamen))
            {
            
            }
        }
        private void kayttajantiiviste()
        {
            using (StreamWriter sw = new StreamWriter(fileNamenn))
            {
                MD5CryptoServiceProvider md5Kryptaaja = new MD5CryptoServiceProvider();
                byte[] data = System.Text.Encoding.ASCII.GetBytes(textBox1.Text);
                data = md5Kryptaaja.ComputeHash(data);

                kayttajamd5tiiviste = "";
                for (int i = 0; i < data.Length; i++)
                    kayttajamd5tiiviste += data[i].ToString("x2").ToLower();
                sw.WriteLine(kayttajamd5tiiviste);
            }
        }


        private void Label1_Click (object sender, EventArgs e)
        {

        }



        private void Button1_Click(object sender, EventArgs e)
        {
            kayttajantiiviste();
            if (textBox2.Text == kayttajatunnus && salasana == kayttajamd5tiiviste)
            {
                textBox1.Text = "";
                textBox2.Text = "";
                Tankit form3 = new Tankit();
                form3.Show();
            }
            else
            {
                textBox1.Text = "";
                textBox2.Text = "";
                DialogResult result = MessageBox.Show("Salasana tai käyttäjätunnus väärin");
            }





           

        }

        private void Label2_Click(object sender, EventArgs e)
        {

        }
       

    }
}
