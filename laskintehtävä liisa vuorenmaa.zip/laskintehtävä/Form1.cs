﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace laskintehtävä
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            
            textBox3.Text = "" + int.Parse(textBox1.Text)+ "+" +int.Parse (textBox2.Text)+"="+(int.Parse(textBox1.Text) + int.Parse(textBox2.Text));

            
            string lasku = textBox3.Text;
            if (checkBox1.Checked)
            {
                KirjoitaTiedostoon(lasku);
            }
           
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {
            textBox3.Text = "" + int.Parse(textBox1.Text) + "-" + int.Parse(textBox2.Text) + "=" + (int.Parse(textBox1.Text) - int.Parse(textBox2.Text));
            
            string lasku = textBox3.Text;
            if (checkBox1.Checked)
            {
                KirjoitaTiedostoon(lasku);
            }

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            textBox3.Text = "" + int.Parse(textBox1.Text) + "/" + int.Parse(textBox2.Text) + "=" + (int.Parse(textBox1.Text) / int.Parse(textBox2.Text));
            
            string lasku = textBox3.Text;
            if (checkBox1.Checked)
            {
                KirjoitaTiedostoon(lasku);
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            textBox3.Text = "" + int.Parse(textBox1.Text) + "*" + int.Parse(textBox2.Text) + "=" + (int.Parse(textBox1.Text) * int.Parse(textBox2.Text));
            
            string lasku = textBox3.Text;
            if (checkBox1.Checked)
            {
                KirjoitaTiedostoon(lasku);
            }

        }

        private void SuljeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Oletko varma", "ikkuna suljetaan", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
                KirjoitaTiedostoon("ohjelma suljettu " + DateTime.Now);

            }
            
        }

        private void ValikkoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void TyhjennäToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        public static void KirjoitaTiedostoon(string laskutulos)

        {
            string Tiedostopolku = "c:/temp/nelilaskin.txt";
            StreamWriter tw = new StreamWriter(Tiedostopolku, true);
            tw.WriteLine(laskutulos); 
            tw.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            KirjoitaTiedostoon("ohjelma avattu " + DateTime.Now);
        }

        private void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}







